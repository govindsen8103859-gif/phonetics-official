(() => {
  'use strict';
  const byId = (id) => document.getElementById(id);
  const menuToggle = byId('menuToggle');
  const mainNav = byId('mainNav');
  menuToggle?.addEventListener('click', () => {
    const open = mainNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    menuToggle.textContent = open ? '×' : '☰';
  });
  mainNav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    if (menuToggle) { menuToggle.textContent = '☰'; menuToggle.setAttribute('aria-label', 'Open navigation'); }
  }));
  byId('year').textContent = String(new Date().getFullYear());

  const searchForm = byId('searchForm');
  const searchInput = byId('phoneSearch');
  const searchFeedback = byId('searchFeedback');
  searchForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const query = searchInput.value.trim();
    searchFeedback.textContent = query
      ? `No approved listings found for “${query}”. Search will work with live inventory after the database is connected.`
      : 'There are no approved phones listed yet. Check back after listings are reviewed.';
  });

  const sellerForm = byId('sellerForm');
  const sellerResult = byId('sellerResult');
  sellerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    sellerResult.className = 'form-result';
    if (!sellerForm.checkValidity()) {
      sellerForm.reportValidity();
      sellerResult.classList.add('error');
      sellerResult.textContent = 'Please complete all required fields correctly.';
      return;
    }
    const proof = sellerForm.elements.proof_available.value;
    if (proof !== 'yes') {
      sellerResult.classList.add('error');
      sellerResult.textContent = 'Submission cannot proceed: Phonetics requires a genuine purchase bill or other proof accepted by the team. No data was sent or saved.';
      return;
    }
    sellerResult.classList.add('error');
    sellerResult.textContent = 'Backend is not connected yet. For your privacy, this form has NOT sent or saved any details. Do not enter real personal information until secure storage is enabled.';
  });

  byId('buyerInfoButton').addEventListener('click', () => {
    byId('buyerFeedback').textContent = 'Purchase requests will be enabled when approved listings and secure backend storage are connected. No request has been created.';
  });
})();